# C-Lab08-24676

Question 1: 

Create a C# Console Application which can get the scalar/ linear summation of an array with 10 elements. Ask the user to enter the values for the array.

Question 2:

Create a C# program that can find minimum and maximum from a given Single Dimensional Array.

Question 3:

Create a C# program that can sort a Single dimensional array according to ascending and descending order.

Question 4:

Create a C# program to find the minimum and maximum values from a 2D array.

Question 5:

Create a C# program that can multiply two 2x2 Matrices.
